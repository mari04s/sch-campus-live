function findField(value, names) {
  if (!value || typeof value !== 'object') return null;
  for (const [key, item] of Object.entries(value)) {
    if (names.includes(key.toLowerCase()) && (typeof item === 'string' || typeof item === 'number')) {
      return String(item).slice(0, 240);
    }
    const nested = findField(item, names);
    if (nested) return nested;
  }
  return null;
}

function xmlField(text, names) {
  for (const name of names) {
    const match = text.match(new RegExp(`<${name}\\b[^>]*>([^<]*)</${name}>`, 'i'));
    if (match) return match[1].slice(0, 240);
  }
  return null;
}

function getProviderError(error) {
  const body = error?.response?.data;
  let parsed = body;
  if (typeof body === 'string') {
    try {
      parsed = JSON.parse(body);
    } catch {
      parsed = null;
    }
  }

  const codeNames = ['returnauthmsg', 'errcode', 'resultcode', 'code'];
  const messageNames = ['returnreason', 'errmsg', 'resultmsg', 'message'];
  const text = typeof body === 'string' ? body : '';
  return {
    status: error?.response?.status ?? null,
    code: findField(parsed, codeNames) || xmlField(text, ['returnAuthMsg', 'errCode', 'resultCode']),
    message: findField(parsed, messageNames) || xmlField(text, ['returnReason', 'errMsg', 'resultMsg']),
  };
}

module.exports = getProviderError;
