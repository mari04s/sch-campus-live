require('dotenv').config();
const axios = require('axios');

// Uses the latest available hourly observation for the KMA API
function getBaseDateTime() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(new Date()).reduce((out, part) => {
    out[part.type] = part.value;
    return out;
  }, {});
  let year = Number(parts.year);
  let month = Number(parts.month);
  let day = Number(parts.day);
  let hour = Number(parts.hour);
  if (Number(parts.minute) < 10) {
    hour -= 1;
    if (hour < 0) {
      hour = 23;
      const previous = new Date(Date.UTC(year, month - 1, day) - 86400000);
      year = previous.getUTCFullYear();
      month = previous.getUTCMonth() + 1;
      day = previous.getUTCDate();
    }
  }
  return {
    base_date: `${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}`,
    base_time: `${String(hour).padStart(2, '0')}00`,
  };
}
async function getWeather() {
  const url = 'https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst';
  const { base_date, base_time } = getBaseDateTime();

  try {
    const response = await axios.get(url, {
      params: {
        ServiceKey: process.env.KMA_SERVICE_KEY,
        pageNo: 1,
        numOfRows: 10,
        dataType: 'JSON',
        base_date,
        base_time,
        nx: Number(process.env.KMA_NX || 60),
        ny: Number(process.env.KMA_NY || 110),
      },
    });

    return {
      success: true,
      data: response.data.response.body.items.item,
      error: null,
    };
  } catch (err) {
    return {
      success: false,
      data: null,
      error: err.message,
    };
  }
}

module.exports = getWeather;

