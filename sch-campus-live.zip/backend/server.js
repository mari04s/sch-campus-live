const express = require('express');
const path = require('path');
const cors = require('cors');
const weatherRoute = require('./routes/weather');
const airRoute = require('./routes/air');

const app = express();
const PORT = process.env.PORT || 3000;
const responseCache = new Map();
const CACHE_MS = 5 * 60 * 1000;

app.use(cors());
app.use(express.static(path.join(__dirname, '..', 'public')));

function cacheSuccessfulResponse(req, res, next) {
  const key = req.baseUrl;
  const cached = responseCache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    res.set('Cache-Control', 'public, max-age=60, s-maxage=300');
    return res.json(cached.body);
  }
  const sendJson = res.json.bind(res);
  res.json = (body) => {
    if (body?.success) responseCache.set(key, { body, expiresAt: Date.now() + CACHE_MS });
    res.set('Cache-Control', 'public, max-age=60, s-maxage=300');
    return sendJson(body);
  };
  next();
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Only expose the two data routes used by the campus page.
app.use('/weather', cacheSuccessfulResponse, weatherRoute);
app.use('/air', cacheSuccessfulResponse, airRoute);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on port ${PORT}`);
});
