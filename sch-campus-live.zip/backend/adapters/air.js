require('dotenv').config();
const axios = require('axios');
const getProviderError = require('../providerError');

async function getAirQuality() {
  const url = 'https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty';

  try {
    const response = await axios.get(url, {
      params: {
        serviceKey: process.env.AIR_SERVICE_KEY.trim(),
        returnType: 'json',
        numOfRows: 10,
        pageNo: 1,
        stationName: process.env.AIR_STATION_NAME || '아산',
        dataTerm: 'DAILY',
        ver: '1.3',
      },
      headers: {
        'User-Agent': 'Mozilla/5.0',
      },
      timeout: 30000,
    });

    return {
      success: true,
      data: response.data.response.body.items,
      error: null,
    };
  } catch (err) {
    console.error('[AirKorea] upstream request failed', JSON.stringify(getProviderError(err)));
    return {
      success: false,
      data: null,
      error: err.message,
    };
  }
}

module.exports = getAirQuality;
